import React from 'react'
import './styles/index.scss';
import { Dashboard } from './features/Dashboard/Dashboard';

export default function DashboardApp() {
  return (
    <Dashboard/>
  )
}
